export interface SuitStatus {
  id: string;
  mark: string;
  codename: string;
  status: 'ACTIVE' | 'STANDBY' | 'MAINTENANCE' | 'DESTROYED';
  powerLevel: number;
}

export interface Satellite {
  id: string;
  name: string;
  location: string;
  status: 'OPTIMAL' | 'DEGRADED' | 'OFFLINE';
  ping: number;
}
