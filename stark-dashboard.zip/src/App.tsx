import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Activity, Cpu, Globe, Infinity as InfinityIcon, ShieldAlert, Terminal, Power } from 'lucide-react';

import { WidgetPanel } from './components/WidgetPanel';
import { ArcReactor } from './components/ArcReactor';
import { TerminalLogs } from './components/TerminalLogs';
import { SuitTracker } from './components/SuitTracker';
import { GlobalDefense } from './components/GlobalDefense';

export default function App() {
  const [systemActive, setSystemActive] = useState(true);

  if (!systemActive) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.button 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          onClick={() => setSystemActive(true)}
          className="flex flex-col items-center gap-4 text-cyan-900 hover:text-cyan-400 transition-colors duration-500"
        >
          <Power size={64} />
          <span className="font-mono text-sm tracking-[0.3em]">INITIALIZE J.A.R.V.I.S.</span>
        </motion.button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-slate-200 overflow-hidden relative selection:bg-cyan-900/50">
      {/* Dynamic Background Noise / Gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-950/20 via-[#050505] to-[#050505] z-0" />
      <div className="absolute inset-0 opacity-[0.03] bg-[url('https://grainy-gradients.vercel.app/noise.svg')] pointer-events-none z-0" />

      {/* Top Navigation / Header */}
      <header className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-cyan-500/10 bg-black/40 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <motion.div 
            initial={{ rotate: -90, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <InfinityIcon size={32} className="text-cyan-400 stark-glow" />
          </motion.div>
          <div>
            <h1 className="font-display text-xl font-bold tracking-[0.2em] uppercase text-white">Stark <span className="text-cyan-400">Industries</span></h1>
            <p className="font-mono text-[10px] tracking-widest text-cyan-500/60">GLOBAL DIAGNOSTIC NETWORK V4.2.1</p>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="font-mono text-xs text-emerald-400 uppercase tracking-widest flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
              JARVIS Online
            </span>
            <span className="font-mono text-[10px] text-slate-500">AUTH: E. STARK</span>
          </div>
          <button 
            onClick={() => setSystemActive(false)}
            className="p-2 border border-cyan-500/30 rounded text-cyan-500/50 hover:text-cyan-400 hover:border-cyan-400 hover:bg-cyan-400/10 transition-all"
          >
            <Power size={18} />
          </button>
        </div>
      </header>

      {/* Main Dashboard Grid */}
      <main className="relative z-10 max-w-[1600px] mx-auto p-4 md:p-6 h-[calc(100vh-80px)]">
        <div className="grid grid-cols-1 md:grid-cols-12 grid-rows-1 md:grid-rows-6 gap-4 md:gap-6 h-full">
          
          {/* Arc Reactor Core (Top Left) */}
          <WidgetPanel 
            title="Arc Reactor Core" 
            icon={<Cpu size={16} />} 
            className="col-span-1 md:col-span-4 row-span-1 md:row-span-3 min-h-[300px]"
            delay={0.1}
          >
            <ArcReactor />
          </WidgetPanel>

          {/* Global Radar (Top Right) */}
          <WidgetPanel 
            title="Defense Network" 
            icon={<Globe size={16} />} 
            className="col-span-1 md:col-span-5 row-span-1 md:row-span-4 min-h-[350px]"
            delay={0.2}
          >
            <GlobalDefense />
          </WidgetPanel>

          {/* Active Alerts (Side column) */}
          <WidgetPanel 
            title="Critical Alerts" 
            icon={<ShieldAlert size={16} />} 
            isAlert 
            className="col-span-1 md:col-span-3 row-span-1 md:row-span-2 min-h-[150px]"
            delay={0.3}
          >
            <div className="flex flex-col h-full justify-center">
              <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded text-red-400">
                <ShieldAlert size={24} className="animate-pulse" />
                <div>
                  <div className="text-xs font-bold tracking-widest uppercase">Breach Detected</div>
                  <div className="font-mono text-[10px] opacity-80">SECTOR 7G - OVERRIDE</div>
                </div>
              </div>
            </div>
          </WidgetPanel>

          {/* Iron Legion / Suit Status */}
          <WidgetPanel 
            title="Iron Legion Assets" 
            icon={<Activity size={16} />} 
            className="col-span-1 md:col-span-3 row-span-1 md:row-span-4 min-h-[300px]"
            delay={0.4}
          >
            <SuitTracker />
          </WidgetPanel>

          {/* Terminal Logs (Bottom Left Span) */}
          <WidgetPanel 
            title="System Diagnostics" 
            icon={<Terminal size={16} />} 
            className="col-span-1 md:col-span-4 row-span-1 md:row-span-3 min-h-[250px]"
            delay={0.5}
          >
            <TerminalLogs />
          </WidgetPanel>

          {/* Metrics or extra feature (Bottom Middle Span) */}
          <WidgetPanel 
            title="Energy Distribution" 
            icon={<Activity size={16} />} 
            className="col-span-1 md:col-span-5 row-span-1 md:row-span-2 min-h-[200px]"
            delay={0.6}
          >
            <div className="h-full flex flex-col justify-center space-y-4 font-mono text-xs">
              <div className="flex items-center justify-between">
                <span className="text-cyan-500">MALLIBU ESTATE</span>
                <span className="text-emerald-400">NOMINAL</span>
              </div>
              <div className="w-full h-1 bg-zinc-800 rounded">
                <div className="h-full bg-emerald-400 w-[95%] stark-glow" />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-cyan-500">STARK TOWER (NY)</span>
                <span className="text-emerald-400">NOMINAL</span>
              </div>
              <div className="w-full h-1 bg-zinc-800 rounded">
                <div className="h-full bg-emerald-400 w-[88%] stark-glow" />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-red-400">PROJECT PEGASUS</span>
                <span className="text-red-500 animate-pulse">OFFLINE</span>
              </div>
              <div className="w-full h-1 bg-zinc-800 rounded">
                <div className="h-full bg-red-500 w-[5%] stark-glow-red" />
              </div>
            </div>
          </WidgetPanel>
        </div>
      </main>
    </div>
  );
}
