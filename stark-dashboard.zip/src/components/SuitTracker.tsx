import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, ShieldAlert, Wrench, Shield } from 'lucide-react';
import { SuitStatus } from '../types';

const SUITS: SuitStatus[] = [
  { id: 'mk-44', mark: 'MK-XLIV', codename: 'Hulkbuster', status: 'STANDBY', powerLevel: 100 },
  { id: 'mk-47', mark: 'MK-XLVII', codename: 'Standard Issue', status: 'ACTIVE', powerLevel: 82 },
  { id: 'mk-50', mark: 'MK-L', codename: 'Bleeding Edge', status: 'MAINTENANCE', powerLevel: 40 },
  { id: 'mk-85', mark: 'MK-LXXXV', codename: 'Endgame', status: 'STANDBY', powerLevel: 99 },
];

export function SuitTracker() {
  return (
    <div className="h-full flex flex-col gap-3">
      {SUITS.map((suit, index) => (
        <motion.div
          key={suit.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 + index * 0.1 }}
          className="bg-cyan-900/10 border border-cyan-500/20 rounded-lg p-3 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-md ${
              suit.status === 'ACTIVE' ? 'bg-cyan-500/20 text-cyan-400 stark-glow' :
              suit.status === 'STANDBY' ? 'bg-slate-500/20 text-slate-400' :
              'bg-amber-500/20 text-amber-400'
            }`}>
              {suit.status === 'ACTIVE' ? <ShieldCheck size={20} /> :
               suit.status === 'STANDBY' ? <Shield size={20} /> :
               <Wrench size={20} />}
            </div>
            <div>
              <div className="font-display font-bold text-sm tracking-widest text-slate-100 uppercase">
                {suit.mark} <span className="opacity-50 text-xs font-sans tracking-normal ml-1">({suit.codename})</span>
              </div>
              <div className={`text-[10px] font-mono mt-0.5 tracking-wider uppercase ${
                suit.status === 'ACTIVE' ? 'text-emerald-400' :
                suit.status === 'STANDBY' ? 'text-slate-400' :
                'text-amber-400'
              }`}>
                [ {suit.status} ]
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-1">
            <div className="text-xs font-mono text-cyan-100">{suit.powerLevel}%</div>
            <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${suit.powerLevel}%` }}
                transition={{ duration: 1, delay: 0.8 }}
                className={`h-full ${
                  suit.powerLevel > 80 ? 'bg-cyan-400 shadow-[0_0_8px_#22d3ee]' :
                  suit.powerLevel > 30 ? 'bg-amber-400 shadow-[0_0_8px_#fbbf24]' :
                  'bg-red-500 shadow-[0_0_8px_#ef4444]'
                }`}
              />
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
