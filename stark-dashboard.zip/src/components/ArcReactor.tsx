import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Zap } from 'lucide-react';

export function ArcReactor() {
  const [output, setOutput] = useState(98.4);

  useEffect(() => {
    // Simulate slight fluctuations in power output
    const interval = setInterval(() => {
      setOutput((prev) => {
        const variance = (Math.random() - 0.5) * 0.4;
        const newOutput = prev + variance;
        if (newOutput > 99.8) return 99.8;
        if (newOutput < 97.0) return 97.0;
        return Number(newOutput.toFixed(1));
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full relative">
      <div className="relative w-48 h-48 flex items-center justify-center">
        {/* Outer Ring */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, ease: 'linear', repeat: Infinity }}
          className="absolute inset-0 border-[3px] border-dashed border-cyan-500/40 rounded-full"
        />
        
        {/* Middle Rotator */}
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 15, ease: 'linear', repeat: Infinity }}
          className="absolute inset-2 border-4 border-t-cyan-400 border-r-cyan-400/20 border-b-cyan-400/20 border-l-cyan-400 rounded-full"
        />

        {/* Coil Ring */}
        <div className="absolute inset-6 rounded-full border border-cyan-300/30 flex items-center justify-center">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1.5 h-full"
              style={{ transform: `rotate(${i * 30}deg)` }}
            >
              <div className="w-full h-3 bg-cyan-200/80 rounded-sm stark-glow" />
            </div>
          ))}
        </div>

        {/* Inner Core */}
        <div className="absolute z-10 w-24 h-24 bg-cyan-100 rounded-full stark-glow shadow-[0_0_40px_10px_rgba(34,211,238,0.6)] flex items-center justify-center">
          <motion.div 
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, ease: 'easeInOut', repeat: Infinity }}
            className="w-16 h-16 bg-white rounded-full blur-[2px]" 
          />
        </div>
      </div>

      <div className="mt-8 text-center">
        <div className="flex items-center justify-center gap-2 text-cyan-400 mb-1">
          <Zap size={16} className="fill-cyan-400" />
          <span className="font-mono text-sm tracking-wider">CORE OUTPUT</span>
        </div>
        <div className="font-display text-4xl font-bold text-white stark-glow-text">
          {output}%
        </div>
        <div className="font-mono text-xs text-cyan-500/70 mt-1">
          PALLADIUM ISOTOPE TRACE: STABLE
        </div>
      </div>
    </div>
  );
}
