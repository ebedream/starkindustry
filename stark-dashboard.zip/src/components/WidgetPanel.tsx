import React from 'react';
import { motion } from 'motion/react';
import { Settings } from 'lucide-react';

interface WidgetPanelProps {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  delay?: number;
  isAlert?: boolean;
}

export function WidgetPanel({ title, icon, children, className = '', delay = 0, isAlert = false }: WidgetPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: 'easeOut' }}
      className={`relative bg-zinc-900/40 backdrop-blur-md border ${
        isAlert ? 'border-red-500/30 stark-glow-red' : 'border-cyan-500/20 stark-glow'
      } rounded-xl overflow-hidden flex flex-col ${className}`}
    >
      {/* Techy corner accents */}
      <div className={`absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 ${isAlert ? 'border-red-500/50' : 'border-cyan-400/50'} rounded-tl-xl`} />
      <div className={`absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 ${isAlert ? 'border-red-500/50' : 'border-cyan-400/50'} rounded-tr-xl`} />
      <div className={`absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 ${isAlert ? 'border-red-500/50' : 'border-cyan-400/50'} rounded-bl-xl`} />
      <div className={`absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 ${isAlert ? 'border-red-500/50' : 'border-cyan-400/50'} rounded-br-xl`} />

      {/* Header */}
      <div className={`px-4 py-3 border-b ${isAlert ? 'border-red-500/20 bg-red-500/10' : 'border-cyan-500/20 bg-cyan-950/20'} flex items-center justify-between`}>
        <div className="flex items-center gap-2">
          <div className={isAlert ? 'text-red-400' : 'text-cyan-400'}>
            {icon || <Settings size={18} />}
          </div>
          <h2 className={`font-display font-semibold text-sm tracking-widest uppercase ${isAlert ? 'text-red-100 stark-glow-text-red' : 'text-cyan-100 stark-glow-text'}`}>
            {title}
          </h2>
        </div>
        <div className={`flex gap-1 ${isAlert ? 'animate-pulse' : ''}`}>
          <div className={`w-2 h-2 rounded-full ${isAlert ? 'bg-red-500' : 'bg-cyan-500 opacity-50'}`} />
          <div className={`w-2 h-2 rounded-full ${isAlert ? 'bg-red-500' : 'bg-cyan-500'}`} />
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 overflow-hidden flex flex-col relative z-10">
        {children}
      </div>
      
      {/* Background scanline effect */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px] opacity-20" />
    </motion.div>
  );
}
