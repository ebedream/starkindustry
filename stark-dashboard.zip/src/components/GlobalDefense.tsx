import React from 'react';
import { motion } from 'motion/react';
import { Globe2 } from 'lucide-react';

export function GlobalDefense() {
  return (
    <div className="h-full flex flex-col items-center justify-center relative">
      {/* Radar Container */}
      <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full border border-cyan-500/30 overflow-hidden flex items-center justify-center bg-cyan-950/20">
        
        {/* Radar grids */}
        <div className="absolute inset-0 border border-cyan-500/20 rounded-full scale-75" />
        <div className="absolute inset-0 border border-cyan-500/20 rounded-full scale-50" />
        <div className="absolute inset-0 border border-cyan-500/20 rounded-full scale-25" />
        
        {/* Crosshairs */}
        <div className="absolute w-full h-[1px] bg-cyan-500/20" />
        <div className="absolute h-full w-[1px] bg-cyan-500/20" />
        
        {/* Map Silhouette (Simple background representation) */}
        <div className="absolute inset-0 opacity-10 flex items-center justify-center">
          <Globe2 size={180} className="text-cyan-400 stroke-[1px]" />
        </div>

        {/* Radar Sweep */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 4, ease: 'linear', repeat: Infinity }}
          className="absolute inset-0 origin-center"
        >
          {/* Sweep gradient */}
          <div className="absolute top-1/2 left-1/2 w-1/2 h-1/2 origin-top-left -rotate-90 bg-gradient-to-br from-cyan-400/40 via-cyan-400/5 to-transparent pointer-events-none" />
          <div className="absolute top-1/2 left-1/2 w-1/2 h-[2px] origin-left bg-cyan-300 shadow-[0_0_10px_#22d3ee]" />
        </motion.div>

        {/* Blips */}
        <motion.div 
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 4, times: [0, 0.1, 1], repeat: Infinity, delay: 0.5 }}
          className="absolute top-1/4 right-1/4 w-2 h-2 rounded-full bg-red-500 stark-glow-red"
        />
        <motion.div 
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 4, times: [0, 0.1, 1], repeat: Infinity, delay: 2.1 }}
          className="absolute bottom-1/3 left-1/4 w-2 h-2 rounded-full bg-cyan-400 stark-glow"
        />
        <motion.div 
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 4, times: [0, 0.1, 1], repeat: Infinity, delay: 3.8 }}
          className="absolute top-2/3 right-1/3 w-2 h-2 rounded-full bg-cyan-400 stark-glow"
        />
      </div>

      <div className="mt-6 flex items-center gap-6 text-xs font-mono text-cyan-500/80 uppercase">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-cyan-400 rounded-full stark-glow" /> Nominal
        </div>
        <div className="flex items-center gap-2 text-red-400/80">
          <div className="w-2 h-2 bg-red-500 rounded-full stark-glow-red animate-pulse" /> Alert Status
        </div>
      </div>
    </div>
  );
}
