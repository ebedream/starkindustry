import React, { useEffect, useRef, useState } from 'react';
import { Terminal } from 'lucide-react';

const mockLogs = [
  "SYSTEM STARTUP SEQUENCE INITIATED...",
  "[OK] CONNECTED TO GLOBAL STARK SECURE CLOUD",
  "LOADING AI PROTOCOLS: J.A.R.V.I.S. ONLINE.",
  "GOOD MORNING. ALL SYSTEMS ARE FUNCTIONING NORMALLY.",
  "[WARN] DETECTED UNAUTHORIZED PING FROM IP 192.168.4.11",
  "ROUTING PING THROUGH FIREWALL...",
  "[OK] CONNECTION BLOCKED.",
  "CALIBRATING REPULSOR OUTPUTS ON MARK XLVII.",
  "CALIBRATION COMPLETE. EFFICIENCY AT 98.4%.",
  "SCANNING LOCAL AIRSPACE FOR ANOMALIES...",
  "[OK] AIRSPACE CLEAR.",
  "syncing_satellite_feed_01...",
  "syncing_satellite_feed_02...",
  "[OK] ORBITAL NETWORK NOMINAL."
];

export function TerminalLogs() {
  const [logs, setLogs] = useState<string[]>([mockLogs[0]]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let index = 1;
    const interval = setInterval(() => {
      if (index < mockLogs.length) {
        setLogs((prev) => [...prev, mockLogs[index]]);
        index++;
      } else {
        // Wrap around with timestamp for endless effect
        const randomLog = mockLogs[Math.floor(Math.random() * (mockLogs.length - 4)) + 4];
        setLogs((prev) => {
          const newLogs = [...prev, `[${new Date().toISOString().split('T')[1].slice(0, -1)}] ${randomLog}`];
          if (newLogs.length > 50) newLogs.shift();
          return newLogs;
        });
      }
    }, 1800);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="h-full flex flex-col font-mono text-xs sm:text-sm">
      <div className="flex-1 overflow-y-auto space-y-2 pr-2">
        {logs.map((log, i) => {
          if (!log) return null;
          const isWarning = log.includes("[WARN]");
          const isOk = log.includes("[OK]");
          return (
            <div 
              key={i} 
              className={`flex gap-2 ${
                isWarning ? 'text-amber-400' : isOk ? 'text-emerald-400' : 'text-cyan-500/80'
              }`}
            >
              <span className="opacity-50 select-none">&gt;</span>
              <span className={isWarning ? 'animate-pulse' : ''}>{log}</span>
            </div>
          );
        })}
        <div ref={bottomRef} className="h-1" />
      </div>
      <div className="mt-4 pt-4 border-t border-cyan-500/20 flex items-center relative gap-2">
        <Terminal size={14} className="text-cyan-400" />
        <span className="text-cyan-400 opacity-70 animate-pulse">_</span>
      </div>
    </div>
  );
}
